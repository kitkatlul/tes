# Daftar File Suara

Semua file berformat **.mp3**, ditaruh di folder `public/sounds/`, namanya harus **persis** seperti di tabel (huruf kecil, tanpa spasi).
File yang belum ada tidak apa-apa: game memakai suara bawaan perangkat untuk bagian itu. Jadi boleh diupload bertahap.

**Tips:** file `benar-1`, `benar-2`, `benar-3`, `menang`, `cocok`, `beda-benar`, dan `puzzle-selesai` sebaiknya pendek (di bawah 2 detik) karena game lanjut ke soal berikutnya setelah ±2 detik.

## A. Kalimat Bubu (37 file)

| Nama file | Yang diucapkan |
|---|---|
| `sambutan.mp3` | Hai, teman-teman! Selamat datang di Petualangan Bubu! Ayo kita bermain! |
| `menang.mp3` | Hebat sekali! Kamu dapat bintang! |
| `benar-1.mp3` | Benar! Pintar! |
| `benar-2.mp3` | Hebat! |
| `benar-3.mp3` | Yeay, benar! |
| `coba-lagi.mp3` | Ayo coba lagi! |
| `belum-tepat.mp3` | Belum tepat. Coba lagi! |
| `tebak-hewan.mp3` | Dengarkan! Hewan apa yang bersuara? |
| `bentuk.mp3` | Cari bentuk yang sama! |
| `warna-merah.mp3` | Pilih buah yang berwarna merah! |
| `warna-kuning.mp3` | Pilih buah yang berwarna kuning! |
| `warna-ungu.mp3` | Pilih buah yang berwarna ungu! |
| `warna-hijau.mp3` | Pilih buah yang berwarna hijau! |
| `warna-oranye.mp3` | Pilih buah yang berwarna oranye! |
| `warna-biru.mp3` | Pilih buah yang berwarna biru! |
| `teman-1.mp3` | Bubu mencari teman. Aku suka makan wortel! Siapa aku? |
| `teman-2.mp3` | Bubu mencari teman. Aku bisa terbang di langit! Siapa aku? |
| `teman-3.mp3` | Bubu mencari teman. Aku berenang di air! Siapa aku? |
| `teman-4.mp3` | Bubu mencari teman. Aku punya belalai panjang! Siapa aku? |
| `teman-5.mp3` | Bubu mencari teman. Aku suka makan pisang! Siapa aku? |
| `teman-6.mp3` | Bubu mencari teman. Aku punya leher yang panjang! Siapa aku? |
| `bunga-air.mp3` | Bunga haus! Pilih air! |
| `bunga-matahari.mp3` | Bunga butuh sinar matahari! |
| `bunga-air-lagi.mp3` | Bunga haus lagi! Pilih air! |
| `bersih-tangan.mp3` | Tanganmu kotor. Ayo pilih yang tepat! |
| `bersih-gigi.mp3` | Gigimu kotor. Ayo pilih yang tepat! |
| `bersih-mainan.mp3` | Mainan berantakan. Ayo pilih yang tepat! |
| `bersih-sampah.mp3` | Ada sampah. Ayo pilih yang tepat! |
| `puzzle.mp3` | Seret kepingan ke tempat yang kosong. Susun jadi singa! |
| `puzzle-selesai.mp3` | Singanya sudah utuh! |
| `geser.mp3` | Geser bentuk ke tempat yang sama! |
| `gelembung.mp3` | Sentuh gelembungnya sampai pecah! |
| `beda.mp3` | Sentuh gambar yang berbeda di baris bawah! |
| `beda-benar.mp3` | Benar! Kamu menemukannya! |
| `memory.mp3` | Sentuh dua kartu. Cari gambar yang sama! |
| `cocok.mp3` | Cocok! |
| `pesan.mp3` | Yeay! Kalian hebat sekali karena sudah mencoba berbagai permainan bersama Bubu! Teruslah belajar, berani mencoba, dan jangan mudah menyerah. Tidak apa-apa jika belum berhasil, kalian selalu punya kesempatan untuk mencoba lagi. Sampai jumpa di petualangan berikutnya, teman-teman! |

## B. Suara hewan (8 file, boleh suara asli hewan)

| Nama file | Isi |
|---|---|
| `kucing.mp3` | Suara kucing: meong |
| `anjing.mp3` | Suara anjing: guk guk |
| `sapi.mp3` | Suara sapi: mooo |
| `ayam.mp3` | Suara ayam: kukuruyuk |
| `kambing.mp3` | Suara kambing: mbek |
| `bebek.mp3` | Suara bebek: kwek kwek |
| `singa.mp3` | Suara singa: auum |
| `kuda.mp3` | Suara kuda: ihihi |
