# Bubu's Little World
Game edukasi PAUD (Petualangan Bubu) untuk anak TK A usia 4-5 tahun. Baca **PANDUAN-LENGKAP.md** untuk cara upload ke GitHub dan Vercel.

- `public/` : isi game (halaman, tampilan, kode, suara)
- `build.js`, `package.json`, `vercel.json` : pengaturan otomatis untuk Vercel (jangan diubah)
