// Menyalin isi folder "public" ke folder "dist" (folder inilah yang ditayangkan Vercel).
// Sekaligus memeriksa: kalau ada file penting yang hilang, build berhenti dan memberi tahu.
const fs = require('fs'), path = require('path');
const wajib = ['index.html', 'style.css', 'minigames.js', 'platformer.js'];
for (const f of wajib) {
  if (!fs.existsSync(path.join('public', f))) { console.error('FILE HILANG: public/' + f); process.exit(1); }
}
fs.rmSync('dist', { recursive: true, force: true });
fs.cpSync('public', 'dist', { recursive: true });
console.log('Build berhasil. Isi dist: ' + fs.readdirSync('dist').join(', '));
